from django.contrib import admin
from core_root_api.job_api.models import Job,ApplicationForm
# Register your models here.
admin.site.register(Job)
admin.site.register(ApplicationForm)