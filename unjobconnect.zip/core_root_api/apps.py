from django.apps import AppConfig


class CoreRootApiConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "core_root_api"
